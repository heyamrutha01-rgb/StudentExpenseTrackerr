// SpendSmart static demo: only the current date is dynamic.
"use strict";

function displayCurrentDate() {
  const dateElement = document.getElementById("currentDate");

  if (dateElement) {
    dateElement.textContent = new Date().toLocaleDateString("en-IN", {
      day: "numeric",
      month: "short",
      year: "numeric"
    });
  }
}

displayCurrentDate();
