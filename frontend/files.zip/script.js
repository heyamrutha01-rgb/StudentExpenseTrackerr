// Only a harmless presentation touch: show today's date in the header.
// No application logic, no event handlers, no network requests.
const dateElement = document.getElementById("current-date");
dateElement.textContent = new Date().toLocaleDateString("en-IN", {
  weekday: "long",
  day: "numeric",
  month: "long",
  year: "numeric"
});
